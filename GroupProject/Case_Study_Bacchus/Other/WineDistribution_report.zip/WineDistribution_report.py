### The wine distribution, are all wines selling as they thought? Is one wine not selling? Which distributor carries which wine

""" 
    Title: Wine_Distribution_report.py
    Group: Bravo
    Author: Campbell, Hinkle, Luna, Orozco, Upadhyaya
    Date: 15 July 2021
    Description: Pulling table data from MySQL database bacchus, 
"""

""" import statements """
import mysql.connector as mysql
from mysql.connector import errorcode


""" database config object """
db = mysql.connect(
    user = "bacchus_user",
    password = "MySQL8IsGreat!",
    host = "127.0.0.1",
    database = "bacchus",
)


cursor = db.cursor()

### creating the function
def distribution_report():
    cursor.execute("SELECT product_id FROM product_orders")
    length_determine = cursor.fetchall()
    
    
    ###getting number of products
    cursor.execute("SELECT product_id FROM product")
    total = cursor.fetchall()
    #print(total)
    num_products = int(len(total))
    x = 0

    ### Ideally this would make it stop once each product has been printed
    while x < num_products:
        cursor.execute("SELECT o.date_of_order, o.product_id, SUM(o.quantity),  o.distributors_id FROM product_orders o INNER JOIN product p on o.product_id = p.product_id")
        dist_info = cursor.fetchall()
        x = x + 1
        print("\n *** Distribution Information Display ***")
        for dist_info in dist_info:
            print("  Date ordered: {}\n  Product ID: {}\n  Quantity Sold to Distributors: {}\n  Distributor ID: {}\n ".format(dist_info[0], dist_info[1], dist_info[2], dist_info[3]))
        
        

distribution_report()

